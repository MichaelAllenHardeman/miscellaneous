## Minimuim Reproduction of Vuclanization Error.

> Produces the following error:

    C:\minimum-example>npm install

    C:\minimum-example>bower install

    C:\minimum-example>gulp
    [18:17:01] Using gulpfile C:\minimum-example\gulpfile.js
    [18:17:01] Starting 'clean'...
    [18:17:01] Finished 'clean' after 10 ms
    [18:17:01] Starting 'default'...
    [18:17:01] Starting 'copy'...
    [18:17:01] copy all files 1.49 kB
    [18:17:01] Finished 'copy' after 36 ms
    [18:17:01] Starting 'html'...
    [18:17:03] html all files 41.09 kB
    [18:17:03] Finished 'html' after 2.01 s
    [18:17:03] Starting 'vulcanize'...
    (node:14856) UnhandledPromiseRejectionWarning: Unhandled promise rejection (rejection id: 2): Error: Error parsing scrip
    t in c:/minimum-example/app/bower_components/vaadin-grid/iron-list-behavior.html at NaN:NaN
    TypeError: Cannot read property 'push' of undefined
        at Object.behaviors (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\declaration-property-handlers.js:52:42
    )
        at Object.enterObjectExpression (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\behavior-finder.js:204:43)

        at applyVisitors (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:31:51)
        at Controller.enter (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:54:20)
        at Controller.__execute (C:\minimum-example\node_modules\estraverse\estraverse.js:395:31)
        at Controller.traverse (C:\minimum-example\node_modules\estraverse\estraverse.js:493:28)
        at Object.traverse (C:\minimum-example\node_modules\estraverse\estraverse.js:705:27)
        at Object.jsParse (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:75:16)
        at Analyzer._processScript (C:\minimum-example\node_modules\hydrolysis\lib\analyzer.js:318:43)
        at C:\minimum-example\node_modules\hydrolysis\lib\analyzer.js:301:44
    (node:14856) DeprecationWarning: Unhandled promise rejections are deprecated. In the future, promise rejections that are
     not handled will terminate the Node.js process with a non-zero exit code.
    (node:14856) UnhandledPromiseRejectionWarning: Unhandled promise rejection (rejection id: 3): Error: Error parsing scrip
    t in c:/minimum-example/app/bower_components/vaadin-grid/iron-list-behavior.html at NaN:NaN
    TypeError: Cannot read property 'push' of undefined
        at Object.behaviors (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\declaration-property-handlers.js:52:42
    )
        at Object.enterObjectExpression (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\behavior-finder.js:204:43)

        at applyVisitors (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:31:51)
        at Controller.enter (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:54:20)
        at Controller.__execute (C:\minimum-example\node_modules\estraverse\estraverse.js:395:31)
        at Controller.traverse (C:\minimum-example\node_modules\estraverse\estraverse.js:493:28)
        at Object.traverse (C:\minimum-example\node_modules\estraverse\estraverse.js:705:27)
        at Object.jsParse (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:75:16)
        at Analyzer._processScript (C:\minimum-example\node_modules\hydrolysis\lib\analyzer.js:318:43)
        at C:\minimum-example\node_modules\hydrolysis\lib\analyzer.js:301:44
    (node:14856) UnhandledPromiseRejectionWarning: Unhandled promise rejection (rejection id: 4): Error in plugin 'gulp-vulc
    anize'
    Message:
        Error parsing script in c:/minimum-example/app/bower_components/vaadin-grid/iron-list-behavior.html at NaN:NaN
    TypeError: Cannot read property 'push' of undefined
        at Object.behaviors (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\declaration-property-handlers.js:52:42
    )
        at Object.enterObjectExpression (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\behavior-finder.js:204:43)

        at applyVisitors (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:31:51)
        at Controller.enter (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:54:20)
        at Controller.__execute (C:\minimum-example\node_modules\estraverse\estraverse.js:395:31)
        at Controller.traverse (C:\minimum-example\node_modules\estraverse\estraverse.js:493:28)
        at Object.traverse (C:\minimum-example\node_modules\estraverse\estraverse.js:705:27)
        at Object.jsParse (C:\minimum-example\node_modules\hydrolysis\lib\ast-utils\js-parse.js:75:16)
        at Analyzer._processScript (C:\minimum-example\node_modules\hydrolysis\lib\analyzer.js:318:43)
        at C:\minimum-example\node_modules\hydrolysis\lib\analyzer.js:301:44
    Details:
        location: [object Object]
        ownerDocument: c:/minimum-example/app/bower_components/vaadin-grid/iron-list-behavior.html
        fileName: C:\minimum-example\app\elements\elements.html
